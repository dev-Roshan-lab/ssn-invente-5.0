package com.sln.practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
