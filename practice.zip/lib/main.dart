import 'package:flutter/material.dart';
import 'package:practice/pages/startpage.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: StartScreen(),
  ));
}
